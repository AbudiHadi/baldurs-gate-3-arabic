Baldur's Gate 3 — Arabic translation, v1.0.2
Translation: Abdullah Hadi (عبدالله هادي)

=============================================
     About this translation
=============================================

- Complete Arabic text for the game: dialogue and subtitles, menus and
  settings, character creation, quests and the journal, items, spells,
  abilities and tooltips, books and letters, tutorials.
- Every line was translated, then independently reviewed before it was
  accepted.
- Audio stays in English; only the text is translated.
- One-click install with install.bat, or manually: one file copied into the Mods folder.

=============================================
     Quick install (one click)
=============================================

1) Unzip the whole archive.
2) Close the game, then double-click install.bat
   (if Windows warns: More info -> Run anyway).
3) Start the game. To remove it: double-click uninstall.bat

=============================================
     Manual install (one minute)
=============================================

1) Close the game.
2) Press Win + R, type the line below and press Enter:
   %LOCALAPPDATA%\Larian Studios\Baldur's Gate 3\Mods
3) Copy ArabicProbe.pak from the zip into that folder.
   (nothing is replaced: the file is only ADDED)
4) Start the game. Keep the game language on English: the translation
   replaces the English text directly.

Important: keep the file name ArabicProbe.pak exactly as it is, directly
inside the Mods folder (not in a subfolder). It does not need to be enabled
in any mod manager.

=============================================
     Notes and known limits
=============================================

- Upgrading from an earlier release: replace the file with the new one.
- A game update may change the game's text: if new English lines appear after
  an update, wait for an updated translation.
- The dialogue log (F3) shows the speaker's name at the end of the first line,
  on the left: the game builds that line itself and translation files cannot
  change it. Subtitles show the name in the right place.
- Inventory search works with the item's English name (shown in brackets after
  the Arabic name).
- Text added by other mods stays in English. Do not combine this translation
  with a mod that replaces the Almarai font or with another translation.
- The Arabic text in this package is tied to its font: copying or editing the
  text outside this package gives unreadable text.

=============================================
     Uninstall / rollback
=============================================

Double-click uninstall.bat, or delete ArabicProbe.pak from the Mods folder. Nothing else in the game was
changed.

=============================================
     Rights
=============================================

This translation is the work of Abdullah Hadi. Do not redistribute it or
present it as someone else's work. Baldur's Gate 3 belongs to Larian Studios;
this is an unofficial fan translation.
