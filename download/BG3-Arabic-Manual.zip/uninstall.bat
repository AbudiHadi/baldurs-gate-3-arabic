@echo off
setlocal
title Baldur's Gate 3 - Arabic translation - uninstall
echo.
set "FILE=%LOCALAPPDATA%\Larian Studios\Baldur's Gate 3\Mods\ArabicProbe.pak"

"%SystemRoot%\System32\tasklist.exe" /FI "IMAGENAME eq bg3.exe" 2>nul | "%SystemRoot%\System32\find.exe" /I "bg3.exe" >nul && goto :running
"%SystemRoot%\System32\tasklist.exe" /FI "IMAGENAME eq bg3_dx11.exe" 2>nul | "%SystemRoot%\System32\find.exe" /I "bg3_dx11.exe" >nul && goto :running
if not exist "%FILE%" goto :absent
del /F "%FILE%"
if exist "%FILE%" goto :delfail
echo  Removed. The game is back to English.
goto :end

:absent
echo  The Arabic translation is not installed - nothing to remove.
goto :end

:delfail
echo  Could not delete the file. Close the game and try again.
goto :end

:running
echo  Baldur's Gate 3 is running. Close the game, then run uninstall.bat again.

:end
echo.
pause
endlocal
