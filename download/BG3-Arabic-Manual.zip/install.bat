@echo off
setlocal
title Baldur's Gate 3 - Arabic translation - install
echo.
echo  Baldur's Gate 3 - Arabic translation - Abdullah Hadi
echo  ----------------------------------------------------
echo.
set "PAK=%~dp0ArabicProbe.pak"
set "PROFILE=%LOCALAPPDATA%\Larian Studios\Baldur's Gate 3"
set "MODS=%LOCALAPPDATA%\Larian Studios\Baldur's Gate 3\Mods"

if not exist "%PAK%" goto :nopak
"%SystemRoot%\System32\tasklist.exe" /FI "IMAGENAME eq bg3.exe" 2>nul | "%SystemRoot%\System32\find.exe" /I "bg3.exe" >nul && goto :running
"%SystemRoot%\System32\tasklist.exe" /FI "IMAGENAME eq bg3_dx11.exe" 2>nul | "%SystemRoot%\System32\find.exe" /I "bg3_dx11.exe" >nul && goto :running
if not exist "%PROFILE%\" goto :noprofile
if not exist "%MODS%\" mkdir "%MODS%"
copy /Y "%PAK%" "%MODS%\ArabicProbe.pak" >nul || goto :copyfail
fc /B "%PAK%" "%MODS%\ArabicProbe.pak" >nul || goto :copyfail
echo  Installed:
echo    %MODS%\ArabicProbe.pak
echo.
echo  Start the game and keep the language on English:
echo  the Arabic text replaces the English text.
echo  To uninstall, run uninstall.bat.
goto :end

:nopak
echo  ArabicProbe.pak was not found next to this file.
echo  Unzip the whole archive first, then run install.bat from the unzipped folder.
goto :end

:running
echo  Baldur's Gate 3 is running. Close the game, then run install.bat again.
goto :end

:noprofile
echo  The game's profile folder does not exist yet:
echo    %PROFILE%
echo  Start Baldur's Gate 3 once, reach the main menu, quit, then run install.bat again.
goto :end

:copyfail
echo  Copy failed. Close the game and try again.

:end
echo.
pause
endlocal
